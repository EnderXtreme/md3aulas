
import './App.css'
import {ButtonLike} from './components/ButtonLike/ButtonLike.jsx'
import {formulario} from './components/form/form.jsx'




function App() {
  


  return (
    <div className="App">
      <h1>Minha Primeira página com React</h1>
      <ButtonLike texto="Enviar"/>
      <ButtonLike texto="LIKE"/>

      <button>ENVIAR</button>

      <formulario/>
    </div>
  )
}

export default App
