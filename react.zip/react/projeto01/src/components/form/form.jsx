
export function formulario() {
    return <form action="source">
    <label htmlFor=""> Informe o Nome: </label>
    <input type="text" name="nome" /><br />

    <label htmlFor=""> Informe o E-mail:</label>
    <input type="text" name="email" /><br />

    <textarea name="caixadetexto" id="caixadetexto" cols="30" rows="10"></textarea><br />

    <button>send</button>
    </form>

}


