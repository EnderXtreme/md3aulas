import { useState } from "react";
import Style from "./style.module.css"
export function ButtonLike() {
    const [count, Setcount] = useState(0)
    return <button className={Style.btn} onClick={() => Setcount(count+1)}>{count}</button>
}