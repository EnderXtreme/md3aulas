import {useState} from "react";

export function Formulario() {
const [nome, setNome] =useState('')
const [email, setEmail] = useState('')
const [comentario, setComentario] = useState('')

const NomeChange = (event)=>{ setNome(event.target.value)}
const EmailChange = (event)=>{ setEmail(event.target.value)}
const ComentarioChange = (event)=>{ setComentario(event.target.value)}
const Submit=(event)=>{ alert ("Sr(a)" + nome + ",seus dados foram enviados com sucesso") 
                    event.preventDefault()}
const Reset=(event) => {setNome(event.target.value="")
                    setEmail(event.target.value="")
                    setComentario(event.target.value="")}

    return (        
        <form onSubmit={(event) => {Submit(event)}}>
                <h1>FORMULÁRIO DE CADASTRO</h1>

                <label htmlFor="nome"> Informe o Nome: </label><br/>
                <input type="text" value={nome} required onChange={(event) => {NomeChange(event)}}  /><br />

                <label htmlFor="email"> Informe o E-mail:</label><br/>
                <input type="email" value={email} required onChange={(event) => {EmailChange(event)}} /><br /><br />

                <textarea  cols="50" rows="20" value={comentario} required onChange={(event) => {ComentarioChange(event)}}></textarea><br/>

                <input type="submit" value="ENVIAR" />
                <input type="button" onClick={(event) => Reset(event)} value="LIMPAR" />
                
                <div class="form-group">
                            <label for="senha">Senha*</label>
                            <input type="password" class="form-control" id="senha" placeholder="Informe a senha do usuário"
                                   maxlength="10" required>
                        </div>
                        <div class="form-group">
                            <label for="c_senha">Confirme a Senha*</label>
                            <input type="password" class="form-control" id="c_senha" placeholder="Confirme a senha do usuário"
                                   maxlength="10" required>
                        </div>

        </form>
    )
}