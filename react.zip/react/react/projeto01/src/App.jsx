
import './App.css'
import {ButtonLike} from './components/ButtonLike/ButtonLike.jsx'
import {Formulario} from './components/form/form.jsx'




function App() {
  


  return (
    <div className="App">
      <h1>Minha Primeira página com React</h1>
      <ButtonLike texto="Enviar"/>
      <ButtonLike texto="LIKE"/>

      <Formulario/>
    </div>
  )
}

export default App
